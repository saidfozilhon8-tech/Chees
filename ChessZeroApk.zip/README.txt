CHESS ZERO - APK (com.chesszero.board)
1. Создайте на GitHub новый репозиторий и загрузите в него ВСЕ файлы этого проекта (включая папку .github).
2. Вкладка Actions -> Build APK -> дождитесь зелёной галочки (3-5 минут).
3. Откройте готовый запуск -> внизу Artifacts -> ChessZero-apk -> скачайте и установите APK.
Игра: app/src/main/assets/index.html. Чтобы обновить игру, замените этот файл и сделайте commit.
Подпись: app/chesszero.keystore (пароль chesszero2026) - оставьте как есть, тогда обновления ставятся поверх.
